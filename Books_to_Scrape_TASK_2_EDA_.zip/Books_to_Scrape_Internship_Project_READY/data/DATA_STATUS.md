# Dataset status

The project package contains a **verified 20-row sample** from the first Books to Scrape catalogue page.

This is intentional: the packaging environment cannot make the live HTTP requests required to collect the full catalogue. The project therefore does not fabricate or relabel sample data as a 1,000-row live scrape.

To generate the full dataset in an internet-enabled environment:

```bash
python run_project.py
```

The scraper follows pagination dynamically and writes:

`data/books_scraped.csv`

The analysis script then creates:

`outputs/analysis_workbook.xlsx`

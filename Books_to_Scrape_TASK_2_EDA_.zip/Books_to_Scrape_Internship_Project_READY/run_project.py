"""
One-command runner for the internship project.

Full run:
    python run_project.py

Quick test:
    python run_project.py --max-pages 2
"""
from __future__ import annotations
import argparse
import subprocess
import sys
from pathlib import Path

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-pages", type=int, default=None)
    parser.add_argument("--delay", type=float, default=1.0)
    args = parser.parse_args()

    cmd = [sys.executable, "src/scraper.py", "--delay", str(args.delay)]
    if args.max_pages is not None:
        cmd += ["--max-pages", str(args.max_pages)]
    subprocess.run(cmd, check=True)

    subprocess.run(
        [sys.executable, "src/analyze.py", "--input", "data/books_scraped.csv"],
        check=True
    )

if __name__ == "__main__":
    main()

# Internship Project — Automated Web Scraping of Books to Scrape

## Task alignment

This project directly addresses **Task 1: Web Scraping**:

- Uses Python libraries **Requests** and **BeautifulSoup**.
- Collects a relevant dataset from a public web page.
- Handles HTML structure and multi-page navigation.
- Creates a structured custom dataset for analysis.
- Uses Pandas for cleaning and Matplotlib for analysis/visualization.

## Source

**Books to Scrape:** https://books.toscrape.com/

Books to Scrape is a purpose-built web-scraping sandbox. Its public sandbox documentation lists 1,000 book items, pagination, up to 20 items per page, and no JavaScript requirement for the books section.

The site's own product page also states that the prices and ratings are randomly assigned and have no real-world meaning. Therefore, this project is presented as a **technical data-acquisition and analytics demonstration**, not as a real market-pricing study.

## Project architecture

Website
→ HTTP request
→ HTML response
→ BeautifulSoup parsing
→ Book-card extraction
→ Pagination
→ Data cleaning/validation
→ CSV
→ Pandas EDA
→ Excel/Power BI-ready workbook
→ Charts

## Files

- `run_project.py` — one-command execution.
- `src/scraper.py` — production-style scraper with retries, timeout, pagination, checkpointing and validation.
- `src/analyze.py` — EDA, summary metrics, charts and Excel workbook.
- `data/sample_books_page1.csv` — verified 20-book sample included for offline inspection.
- `data/sample_books_page1.xlsx` — Excel version of the sample.
- `outputs/` — example analysis outputs generated from the verified sample.
- `report/` — internship report in DOCX and PDF.
- `presentation/` — short project presentation.
- `notebooks/` — Jupyter notebook version of the analysis workflow.

## Installation

1. Install Python 3.10+.
2. Open Command Prompt/Terminal in this project folder.
3. Install packages:

```bash
pip install -r requirements.txt
```

## Run the project

### Quick test — first 2 pages

```bash
python run_project.py --max-pages 2 --delay 1
```

### Full project run

```bash
python run_project.py
```

The scraper follows the site's `Next` link until pagination ends. It does **not** rely on a hard-coded list of page URLs.

The final dataset is saved as:

`data/books_scraped.csv`

The analysis workbook is saved as:

`outputs/analysis_workbook.xlsx`

## Data fields

| Field | Description |
|---|---|
| `title` | Full book title |
| `price_gbp` | Numeric book price in GBP |
| `rating` | Numeric star rating from 1 to 5 |
| `rating_label` | Original rating label: One–Five |
| `availability` | In stock / Out of stock |
| `detail_url` | Book detail-page URL |
| `image_url` | Book image URL when available |
| `source_page` | Listing page from which the book was extracted |

## Data-quality controls

The scraper:

- checks HTTP status codes;
- uses a request timeout;
- retries transient errors such as 429/5xx responses;
- identifies book cards using the page's HTML structure;
- converts prices to numeric values;
- converts rating labels to 1–5;
- removes duplicate detail URLs;
- rejects invalid ratings and negative prices;
- saves a checkpoint after every page.

## Important submission note

The included CSV is deliberately a **verified 20-book sample** so the project remains honest and reproducible even when the live website cannot be reached from the packaging environment.

For your actual internship demonstration, run:

```bash
python run_project.py
```

This creates the live full-catalog CSV from the source website at execution time.

Do **not** claim that the 20-row sample is the full dataset.

## Suggested viva explanation

> “I selected Books to Scrape because it is a public sandbox created specifically for web-scraping practice. I used Requests to retrieve HTML and BeautifulSoup to parse the repeated product-card structure. The scraper extracts book-level attributes, follows the Next link for pagination, cleans the values with Pandas and saves the resulting dataset to CSV. I then perform exploratory analysis and export an Excel workbook that can be used for reporting or Power BI.”

## Ethical considerations

- Use public pages and respect site terms/robots guidance.
- Keep request rates reasonable.
- Do not bypass authentication, CAPTCHAs or access controls.
- Avoid collecting personal or sensitive information.
- Identify the purpose of the scraper clearly.
- Treat the Books to Scrape prices/ratings as demonstration data only.

"""
TASK 2 — Exploratory Data Analysis (EDA)

Run:
    python task2_eda/eda.py
or:
    python task2_eda/eda.py --input data/books_scraped.csv

If the full live dataset does not exist, the script automatically uses the
verified 20-book sample so the project remains reproducible.
"""

from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt

RATING_ORDER = ["One", "Two", "Three", "Four", "Five"]

def load_data(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    if "page" in df.columns and "source_page" not in df.columns:
        df = df.rename(columns={"page": "source_page"})
    required = {"title","price_gbp","rating","rating_label","availability","detail_url","source_page"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    df["price_gbp"] = pd.to_numeric(df["price_gbp"], errors="coerce")
    df["rating"] = pd.to_numeric(df["rating"], errors="coerce")
    df["title_length"] = df["title"].astype(str).str.len()
    return df

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=Path("data/books_scraped.csv"))
    args = parser.parse_args()

    input_path = args.input
    if not input_path.exists():
        input_path = Path("data/sample_books_page1.csv")
        print(f"Live dataset not found; using verified sample: {input_path}")

    df = load_data(input_path)
    out = Path("task2_eda/outputs")
    charts = Path("task2_eda/charts")
    out.mkdir(parents=True, exist_ok=True)
    charts.mkdir(parents=True, exist_ok=True)

    # Descriptive profile
    profile = df[["price_gbp","rating","title_length"]].describe().T
    profile["median"] = df[["price_gbp","rating","title_length"]].median()
    profile.to_csv(out/"numeric_profile.csv")

    # Missingness and duplicates
    missing = df.isna().sum()
    pd.DataFrame({"missing_count":missing, "missing_percentage":missing/len(df)*100}).to_csv(out/"missingness.csv")
    pd.DataFrame({
        "duplicate_detail_urls":[df["detail_url"].duplicated().sum()],
        "duplicate_titles":[df["title"].duplicated().sum()]
    }).to_csv(out/"duplicate_checks.csv", index=False)

    # Outliers
    q1, q3 = df["price_gbp"].quantile([.25,.75])
    iqr = q3-q1
    lower, upper = q1-1.5*iqr, q3+1.5*iqr
    df[(df["price_gbp"]<lower)|(df["price_gbp"]>upper)].to_csv(out/"price_outliers.csv", index=False)

    # Hypothesis tests
    groups = [g["price_gbp"].dropna().values for _,g in df.groupby("rating")]
    results = []
    s = stats.spearmanr(df["price_gbp"], df["rating"])
    results.append(["Spearman", s.statistic, s.pvalue])
    k = stats.kruskal(*groups)
    results.append(["Kruskal-Wallis", k.statistic, k.pvalue])
    low = df.loc[df["rating"]<=2, "price_gbp"]
    high = df.loc[df["rating"]>=4, "price_gbp"]
    m = stats.mannwhitneyu(low, high, alternative="two-sided")
    results.append(["Mann-Whitney U", m.statistic, m.pvalue])
    pd.DataFrame(results, columns=["test","statistic","p_value"]).to_csv(out/"hypothesis_tests_compact.csv", index=False)

    # Charts
    counts = df["rating_label"].value_counts().reindex(RATING_ORDER, fill_value=0)
    fig, ax = plt.subplots(figsize=(8,5))
    ax.bar(counts.index, counts.values)
    ax.set_title("Distribution of Book Ratings")
    ax.set_xlabel("Rating"); ax.set_ylabel("Number of Books")
    fig.tight_layout(); fig.savefig(charts/"01_rating_distribution.png", dpi=180, bbox_inches="tight"); plt.close(fig)

    fig, ax = plt.subplots(figsize=(8,5))
    ax.hist(df["price_gbp"].dropna(), bins=10)
    ax.set_title("Distribution of Book Prices")
    ax.set_xlabel("Price (GBP)"); ax.set_ylabel("Number of Books")
    fig.tight_layout(); fig.savefig(charts/"02_price_distribution.png", dpi=180, bbox_inches="tight"); plt.close(fig)

    fig, ax = plt.subplots(figsize=(8,5))
    ax.scatter(df["rating"], df["price_gbp"])
    ax.set_title("Price vs. Rating")
    ax.set_xlabel("Rating"); ax.set_ylabel("Price (GBP)")
    fig.tight_layout(); fig.savefig(charts/"03_price_vs_rating.png", dpi=180, bbox_inches="tight"); plt.close(fig)

    print(f"EDA completed for {len(df):,} rows.")

if __name__ == "__main__":
    main()

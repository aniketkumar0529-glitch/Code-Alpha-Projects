# Task 2 Submission Checklist

- [ ] Run Task 1 full scraper in an internet-enabled environment.
- [ ] Confirm the full CSV is created and validated.
- [ ] Run `python task2_eda/eda.py --input data/books_scraped.csv`.
- [ ] Open `EDA_Analysis_Workbook.xlsx`.
- [ ] Review all 7 charts.
- [ ] Read the EDA report.
- [ ] Review the presentation/viva points.
- [ ] Do not generalize the 20-row packaged sample to the full catalogue.
- [ ] Replace/add your name, institute, internship provider and date if required.
- [ ] Keep statistical interpretation as association, not causation.

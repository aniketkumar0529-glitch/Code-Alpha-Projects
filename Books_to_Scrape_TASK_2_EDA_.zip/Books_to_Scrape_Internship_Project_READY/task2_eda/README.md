# Task 2 — Exploratory Data Analysis (EDA)

## Project
**Books to Scrape — Internship Project**

This package is the Task 2 continuation of the Task 1 web-scraping project.

## What this task covers

The supplied internship brief requires:

1. Meaningful questions before analysis.
2. Data structure and data-type exploration.
3. Trends, patterns and anomalies.
4. Hypothesis testing using statistics and visualization.
5. Detection of data issues/problems for further analysis.

This package addresses all five requirements.

## Current dataset status

The package contains a **verified 20-record sample from page 1**. It is intentionally not labelled as the complete 1,000-book catalogue.

The live source currently shows 1,000 results and 20 books on page 1. The website also states that its prices and ratings are randomly assigned and have no real-world meaning.

To run EDA on the full scraped dataset, first run the Task 1 scraper:

```bash
python run_project.py
```

Then run:

```bash
python task2_eda/eda.py --input data/books_scraped.csv
```

If `data/books_scraped.csv` is absent, the EDA script automatically uses the verified sample.

## Main outputs

- `task2_eda/EDA_Analysis_Workbook.xlsx`
- `task2_eda/report/Task_2_EDA_Report.pdf`
- `task2_eda/report/Task_2_EDA_Report.docx`
- `task2_eda/presentation/Task_2_EDA_Presentation.pptx`
- `task2_eda/notebook/Task_2_EDA_Books_to_Scrape.ipynb`
- `task2_eda/eda.py`
- `task2_eda/charts/` — 7 analysis charts
- `task2_eda/outputs/` — machine-readable analysis tables

## Statistical methods

### Assumption checks
- Shapiro–Wilk test for price normality.
- Shapiro–Wilk test for rating distribution.

### Relationship / hypothesis tests
- Spearman rank correlation: price vs rating.
- Kruskal–Wallis H test: price across rating groups.
- Mann–Whitney U test: low ratings (1–2) vs high ratings (4–5).
- One-sample t-test is included only as a descriptive benchmark against a rating of 3; it is not used as the primary inferential method because rating is ordinal/non-normal.

## Sample results

- Mean price: £38.05
- Median price: £41.38
- Mean rating: 2.85/5
- Spearman rho: -0.068, p = 0.776
- Kruskal–Wallis H: 2.310, p = 0.679
- Price outliers by IQR: 0
- Missing image URLs: 19/20

## Important interpretation rule

Do not say that “price causes rating” or that “rating determines price.” The EDA tests association, not causation. Also do not generalize the 20-record sample to the entire catalogue.

## Suggested viva answer

> “Before calculating statistics, I defined analytical questions around price distribution, rating distribution, price-rating association, group differences, outliers and data quality. I profiled data types and missingness, used visualizations to understand distributions, checked normality with Shapiro–Wilk, and then selected non-parametric tests because the sample was non-normal and rating is ordinal. The sample did not provide statistically significant evidence of a price-rating relationship. I also identified practical data-quality issues such as missing image URLs, constant availability and page-level coverage.”


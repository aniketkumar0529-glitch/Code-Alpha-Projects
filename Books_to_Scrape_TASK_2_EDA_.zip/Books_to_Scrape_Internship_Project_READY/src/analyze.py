"""
Books to Scrape — Exploratory Data Analysis
Run from project root:
    python src/analyze.py
    python src/analyze.py --input data/sample_books_page1.csv
"""

from __future__ import annotations

import argparse
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

RATING_ORDER = ["One", "Two", "Three", "Four", "Five"]


def load_data(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {
        "title", "price_gbp", "rating", "rating_label",
        "availability", "detail_url", "source_page"
    }
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    df["price_gbp"] = pd.to_numeric(df["price_gbp"], errors="coerce")
    df["rating"] = pd.to_numeric(df["rating"], errors="coerce")
    return df


def save_chart(fig, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=Path("data/books_scraped.csv"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs"))
    args = parser.parse_args()

    if not args.input.exists():
        fallback = Path("data/sample_books_page1.csv")
        if fallback.exists():
            print(f"Full dataset not found; using verified sample: {fallback}")
            args.input = fallback
        else:
            raise FileNotFoundError(args.input)

    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)
    df = load_data(args.input)

    summary = pd.DataFrame({
        "Metric": [
            "Rows", "Columns", "Average Price (GBP)", "Minimum Price (GBP)",
            "Maximum Price (GBP)", "Average Rating", "Duplicate Titles",
            "Missing Values (all columns)"
        ],
        "Value": [
            len(df), len(df.columns), round(df["price_gbp"].mean(), 2),
            round(df["price_gbp"].min(), 2), round(df["price_gbp"].max(), 2),
            round(df["rating"].mean(), 2), int(df["title"].duplicated().sum()),
            int(df.isna().sum().sum())
        ]
    })
    summary.to_csv(out / "summary_metrics.csv", index=False)

    rating_counts = (
        df["rating_label"].value_counts()
        .reindex(RATING_ORDER, fill_value=0)
        .rename_axis("rating_label")
        .reset_index(name="book_count")
    )
    rating_counts.to_csv(out / "rating_distribution.csv", index=False)

    price_by_rating = (
        df.groupby("rating_label", as_index=False)["price_gbp"].mean()
        .assign(order=lambda x: x["rating_label"].map({v: i for i, v in enumerate(RATING_ORDER)}))
        .sort_values("order")
        .drop(columns="order")
    )
    price_by_rating.to_csv(out / "average_price_by_rating.csv", index=False)

    top10 = df.nlargest(10, "price_gbp")[
        ["title", "price_gbp", "rating_label", "availability"]
    ]
    top10.to_csv(out / "top_10_expensive_books.csv", index=False)

    # 1. Rating distribution
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(rating_counts["rating_label"], rating_counts["book_count"])
    ax.set_title("Book Rating Distribution")
    ax.set_xlabel("Star Rating")
    ax.set_ylabel("Number of Books")
    save_chart(fig, out / "01_rating_distribution.png")

    # 2. Price distribution
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(df["price_gbp"].dropna(), bins=12)
    ax.set_title("Book Price Distribution")
    ax.set_xlabel("Price (GBP)")
    ax.set_ylabel("Number of Books")
    save_chart(fig, out / "02_price_distribution.png")

    # 3. Average price by rating
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(price_by_rating["rating_label"], price_by_rating["price_gbp"])
    ax.set_title("Average Price by Rating")
    ax.set_xlabel("Star Rating")
    ax.set_ylabel("Average Price (GBP)")
    save_chart(fig, out / "03_average_price_by_rating.png")

    # 4. Books by source page
    page_counts = df["source_page"].value_counts().sort_index()
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(page_counts.index, page_counts.values, marker="o")
    ax.set_title("Books Extracted per Source Page")
    ax.set_xlabel("Source Page")
    ax.set_ylabel("Books Extracted")
    save_chart(fig, out / "04_books_per_page.png")

    # Excel workbook for analysis / Power BI import
    xlsx = out / "analysis_workbook.xlsx"
    with pd.ExcelWriter(xlsx, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="Scraped_Data", index=False)
        summary.to_excel(writer, sheet_name="Summary", index=False)
        rating_counts.to_excel(writer, sheet_name="Rating_Distribution", index=False)
        price_by_rating.to_excel(writer, sheet_name="Avg_Price_by_Rating", index=False)
        top10.to_excel(writer, sheet_name="Top_10_Expensive", index=False)

    print(f"Analyzed {len(df):,} rows from {args.input}")
    print(summary.to_string(index=False))
    print(f"Charts and workbook saved to {out}")


if __name__ == "__main__":
    main()

"""
Books to Scrape — Internship Web Scraping Project
Task 1: Web Scraping

Purpose:
    Extract structured book data from the Books to Scrape sandbox,
    follow pagination automatically, clean the fields, and save a CSV.

Run from the project root:
    python src/scraper.py
    python src/scraper.py --max-pages 2 --delay 1.0

The default run follows the site's Next link until pagination ends.
"""

from __future__ import annotations

import argparse
import re
import time
from pathlib import Path
from urllib.parse import urljoin

import pandas as pd
import requests
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "https://books.toscrape.com/"
DEFAULT_OUTPUT = Path("data/books_scraped.csv")
CHECKPOINT_OUTPUT = Path("data/books_scraped_checkpoint.csv")

RATING_MAP = {
    "One": 1,
    "Two": 2,
    "Three": 3,
    "Four": 4,
    "Five": 5,
}

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/131.0 Safari/537.36 "
        "(educational web-scraping internship project)"
    ),
    "Accept-Language": "en-US,en;q=0.9",
}


def build_session() -> requests.Session:
    """Create a session with safe retry behaviour for transient HTTP errors."""
    session = requests.Session()
    retry = Retry(
        total=3,
        connect=3,
        read=3,
        backoff_factor=1.0,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset({"GET"}),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    session.headers.update(HEADERS)
    return session


def fetch_html(session: requests.Session, url: str, timeout: int = 30) -> str:
    """Download a page and fail clearly for non-success HTTP responses."""
    response = session.get(url, timeout=timeout)
    response.raise_for_status()
    response.encoding = response.apparent_encoding or "utf-8"
    return response.text


def parse_price(text: str) -> float:
    """Convert currency text such as '£51.77' to a numeric GBP value."""
    cleaned = text.replace("Â", "").replace("£", "").strip()
    match = re.search(r"\d+(?:\.\d+)?", cleaned)
    if not match:
        raise ValueError(f"Could not parse price: {text!r}")
    return float(match.group())


def parse_rating(element) -> tuple[int | None, str]:
    """Read the rating word stored in the CSS class of p.star-rating."""
    classes = element.get("class", [])
    label = next((item for item in classes if item in RATING_MAP), "Unknown")
    return RATING_MAP.get(label), label


def parse_listing_page(html: str, page_url: str, page_number: int) -> tuple[list[dict], str | None]:
    """Extract all book cards and the next-page URL from one listing page."""
    soup = BeautifulSoup(html, "html.parser")
    rows: list[dict] = []

    for card in soup.select("article.product_pod"):
        title_link = card.select_one("h3 a")
        price_el = card.select_one("p.price_color")
        rating_el = card.select_one("p.star-rating")
        availability_el = card.select_one("p.instock.availability")
        image_el = card.select_one("div.image_container img")

        # A malformed card should not crash the entire run.
        if not title_link or not price_el or not rating_el:
            continue

        rating, rating_label = parse_rating(rating_el)

        detail_url = urljoin(page_url, title_link.get("href", ""))
        image_url = (
            urljoin(page_url, image_el.get("src", ""))
            if image_el and image_el.get("src")
            else ""
        )

        availability_text = (
            availability_el.get_text(" ", strip=True)
            if availability_el
            else ""
        )
        availability = "In stock" if "In stock" in availability_text else "Out of stock"

        rows.append(
            {
                "title": title_link.get("title") or title_link.get_text(" ", strip=True),
                "price_gbp": parse_price(price_el.get_text(" ", strip=True)),
                "rating": rating,
                "rating_label": rating_label,
                "availability": availability,
                "detail_url": detail_url,
                "image_url": image_url,
                "source_page": page_number,
            }
        )

    next_link = soup.select_one("li.next a")
    next_url = urljoin(page_url, next_link.get("href")) if next_link else None
    return rows, next_url


def clean_dataset(df: pd.DataFrame) -> pd.DataFrame:
    """Apply consistent types, remove duplicate book URLs, and validate fields."""
    if df.empty:
        return df

    df = df.copy()
    df["title"] = df["title"].astype("string").str.strip()
    df["price_gbp"] = pd.to_numeric(df["price_gbp"], errors="coerce")
    df["rating"] = pd.to_numeric(df["rating"], errors="coerce").astype("Int64")
    df["rating_label"] = df["rating_label"].astype("string").str.strip()
    df["availability"] = df["availability"].astype("string").str.strip()
    df["detail_url"] = df["detail_url"].astype("string").str.strip()
    df["image_url"] = df["image_url"].fillna("").astype("string").str.strip()
    df["source_page"] = pd.to_numeric(df["source_page"], errors="coerce").astype("Int64")

    df = df.drop_duplicates(subset=["detail_url"], keep="first")
    df = df.dropna(subset=["title", "price_gbp", "rating", "detail_url"])

    invalid_rating = ~df["rating"].isin([1, 2, 3, 4, 5])
    if invalid_rating.any():
        raise ValueError("Validation failed: rating outside the 1–5 range.")

    if (df["price_gbp"] < 0).any():
        raise ValueError("Validation failed: negative price detected.")

    return df.reset_index(drop=True)


def save_checkpoint(rows: list[dict], path: Path) -> None:
    """Save progress after every page so a long run can be recovered."""
    if not rows:
        return
    checkpoint = clean_dataset(pd.DataFrame(rows))
    path.parent.mkdir(parents=True, exist_ok=True)
    checkpoint.to_csv(path, index=False, encoding="utf-8-sig")


def scrape_catalog(max_pages: int | None = None, delay: float = 1.0) -> pd.DataFrame:
    session = build_session()
    url = BASE_URL
    all_rows: list[dict] = []
    page_number = 1

    while url and (max_pages is None or page_number <= max_pages):
        print(f"[Page {page_number}] {url}")
        html = fetch_html(session, url)
        rows, next_url = parse_listing_page(html, url, page_number)

        if not rows:
            raise RuntimeError(
                f"No book cards were extracted from page {page_number}. "
                "The website HTML structure may have changed."
            )

        all_rows.extend(rows)
        print(f"  extracted={len(rows)} | cumulative={len(all_rows)}")
        save_checkpoint(all_rows, CHECKPOINT_OUTPUT)

        url = next_url
        page_number += 1

        if url:
            time.sleep(max(delay, 0.0))

    df = clean_dataset(pd.DataFrame(all_rows))
    return df


def main() -> None:
    parser = argparse.ArgumentParser(description="Scrape Books to Scrape.")
    parser.add_argument(
        "--max-pages",
        type=int,
        default=None,
        help="Optional page limit for testing. Default: follow all pages.",
    )
    parser.add_argument(
        "--delay",
        type=float,
        default=1.0,
        help="Seconds between page requests. Default: 1.0",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_OUTPUT,
        help="CSV output path.",
    )
    args = parser.parse_args()

    if args.max_pages is not None and args.max_pages < 1:
        parser.error("--max-pages must be at least 1.")

    df = scrape_catalog(max_pages=args.max_pages, delay=args.delay)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.output, index=False, encoding="utf-8-sig")

    print("\nSCRAPING COMPLETE")
    print(f"Rows saved: {len(df):,}")
    print(f"Columns: {len(df.columns)}")
    print(f"Output: {args.output}")
    print(f"Average price: £{df['price_gbp'].mean():.2f}")
    print("Rating distribution:")
    print(df["rating_label"].value_counts().reindex(
        ["One", "Two", "Three", "Four", "Five"], fill_value=0
    ))


if __name__ == "__main__":
    main()

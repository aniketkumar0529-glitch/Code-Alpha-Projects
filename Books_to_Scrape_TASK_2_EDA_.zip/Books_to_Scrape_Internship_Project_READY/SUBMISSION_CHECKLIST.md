# Submission Checklist

- [ ] Install dependencies with `pip install -r requirements.txt`.
- [ ] Run the quick test successfully.
- [ ] Run the full scraper successfully on an internet-enabled computer.
- [ ] Confirm `data/books_scraped.csv` contains the live full-catalog result.
- [ ] Run the analysis and open `outputs/analysis_workbook.xlsx`.
- [ ] Review the generated charts.
- [ ] Read the report and presentation before submission.
- [ ] Replace/add your institute, internship provider and submission date if required by your program.
- [ ] Do not describe the included 20-row sample as the full dataset.
